README.md 
//This is a calculator that I made. I used the Jack OS API math operations to 
//multiply, divide, and sqrt. In my program you can compute the average of a //sequences of intergers, multiply, divide, and take the square root of an //integer. Since the Jack language does not support float values, I calculated 
//a way to get the remainder. Press Q to get the Average, P to multiply, W to //divide, and X to get the square root. 
